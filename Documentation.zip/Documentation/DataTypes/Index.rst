.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Data types
----------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Introduction/Index
   DataTypesReference/Index

