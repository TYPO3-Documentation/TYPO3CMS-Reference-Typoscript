.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


static\_template
^^^^^^^^^^^^^^^^

This section of the TypoScript reference is used to introduce the
standard templates that come with TYPO3 in the static table
"static\_template".

In newer versions of TYPO3 the static templates are an own system
extension. Old records in the database table static\_template are NOT
changed from version to version! Still changes may appear!

