.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Appendix B – Standard Templates
-------------------------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   StaticTemplate/Index
   Media/Index

