.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Media
^^^^^

The standard templates use some standard media-files, like gif-images
and fonts. These are situated in the folder
"typo3/sysext/statictemplates/media/" (in older versions in
"typo3/sysext/cms/tslib/media/" or just in "media/") relative to the
root of the TYPO3-website.

