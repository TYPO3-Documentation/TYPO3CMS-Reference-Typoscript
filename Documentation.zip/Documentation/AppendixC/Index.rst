.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Appendix C – PHP include scripts
--------------------------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Introduction/Index
   TyposcriptConfiguration/Index
   IncludingYourScript/Index
   CaseStory/Index
   StoringUser-dataOrSession-data/Index
   UsingTheBuiltInShoppingBasket/Index

