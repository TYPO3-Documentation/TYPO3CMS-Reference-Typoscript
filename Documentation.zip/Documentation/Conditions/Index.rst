.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Conditions
----------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Reference/Index

