.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


About this document
^^^^^^^^^^^^^^^^^^^

This document is a complete reference to all objects and properties of
TypoScript as used in TYPO3 templates (and not in TSconfig).

For explanations about the syntax of TypoScript itself, please refer
to the "TypoScript Syntax and In-Depth Study" manual.

This version is updated for TYPO3 version 4.7.

