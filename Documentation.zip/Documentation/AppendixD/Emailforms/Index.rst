.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


Emailforms
^^^^^^^^^^

Detected by the mainscript "index.php" looking for the var
"formtype\_mail" to be set (could be the submit-button).

Input MUST be POST method. And the REFERER and HTTP\_HOST must match.
Also the locationData var must be sent and at least point to the uid
of a readable page.

