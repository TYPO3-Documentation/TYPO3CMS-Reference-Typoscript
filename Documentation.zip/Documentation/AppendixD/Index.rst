.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


Appendix D – index.php
----------------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Introduction/Index
   SubmittingDataToIndexphp/Index
   Search/Index
   Emailforms/Index
   Database-submit/Index

