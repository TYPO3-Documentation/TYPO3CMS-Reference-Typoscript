.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


"FE\_DATA"
^^^^^^^^^^

**Note** : These options were deprecated since TYPO3 4.6 and have
been removed in TYPO3 6.0.

.. ### BEGIN~OF~TABLE ###

.. container:: table-row

   Property
         Property:

   Data type
         Data type:

   Description
         Description:

   Default
         Default:


.. container:: table-row

   Property
         array of tableNames

   Data type
         ->FE\_TABLE

   Description


   Default


.. ###### END~OF~TABLE ######

[tsref:FEData]

