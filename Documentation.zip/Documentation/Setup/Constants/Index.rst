.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


"CONSTANTS"
^^^^^^^^^^^

.. ### BEGIN~OF~TABLE ###

.. container:: table-row

   Property
         Property:

   Data type
         Data type:

   Description
         Description:

   Default
         Default:


.. container:: table-row

   Property
         Array...

   Data type
         *string*

   Description
         Constants.

         **Examples:**

         .EMAIL =  *email@email.com*

         Now if parseFunc anywhere is configured with constants=1 then all
         cases of the string ###EMAIL### will be substituted in the text.

         see ->parseFunc

   Default


.. ###### END~OF~TABLE ######

[tsref:constants]

